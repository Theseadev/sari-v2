-- MySQL dump 10.13  Distrib 8.4.3, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sari_v2
-- ------------------------------------------------------
-- Server version	8.4.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `description` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_logs_user` (`user_id`),
  KEY `idx_logs_action` (`action`),
  KEY `idx_logs_created` (`created_at`),
  CONSTRAINT `fk_logs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES (7,NULL,'logout','Logout: Fahrul','local',NULL,'2026-07-19 08:09:12'),(8,1,'login','Login: Super Administrator','unknown',NULL,'2026-07-19 08:09:33'),(9,1,'logout','Logout: Super Administrator','local',NULL,'2026-07-19 08:10:06'),(10,1,'login','Login: Super Administrator','unknown',NULL,'2026-07-19 08:10:15'),(11,1,'logout','Logout: Super Administrator','local',NULL,'2026-07-19 08:11:39'),(12,NULL,'login','Login: Ahmad Pustakawan','unknown',NULL,'2026-07-19 08:11:52'),(13,NULL,'logout','Logout: Ahmad Pustakawan','local',NULL,'2026-07-19 08:29:51'),(14,NULL,'login','Login: Ahmad Pustakawan','unknown',NULL,'2026-07-19 08:30:07'),(15,NULL,'login','Login: Muhammad Fahrul Bahri','unknown',NULL,'2026-07-19 08:33:49'),(16,NULL,'logout','Logout: Muhammad Fahrul Bahri','local',NULL,'2026-07-19 08:34:02'),(17,NULL,'register','Register: Muhammad Fahrul Bahri','unknown',NULL,'2026-07-19 08:34:31'),(18,NULL,'logout','Logout: Muhammad Fahrul Bahri','local',NULL,'2026-07-19 08:34:41'),(19,1,'login','Login: Super Administrator','unknown',NULL,'2026-07-19 08:34:56'),(20,1,'logout','Logout: Super Administrator','local',NULL,'2026-07-19 08:46:49'),(21,1,'login','Login: Super Administrator','unknown',NULL,'2026-07-19 08:48:28'),(22,1,'logout','Logout: Super Administrator','local',NULL,'2026-07-19 08:55:24'),(23,1,'login','Login: Super Administrator','unknown',NULL,'2026-07-19 08:57:53'),(24,1,'update_book','Mengedit buku: Asuhan Kebidanan pada Ibu Hamil Patologi','local',NULL,'2026-07-19 09:15:36'),(25,1,'update_book','Mengedit buku: Asuhan Kebidanan pada Ibu Hamil Patologi','local',NULL,'2026-07-19 09:15:44'),(26,1,'add_bookmark','Tambah bookmark: Asuhan Kebidanan pada Ibu Hamil Patologi','local',NULL,'2026-07-19 09:15:58'),(27,1,'remove_bookmark','Hapus bookmark: Asuhan Kebidanan pada Ibu Hamil Patologi','local',NULL,'2026-07-19 09:16:21'),(28,1,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-19 09:42:18'),(29,1,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-19 09:44:12'),(30,1,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-19 09:44:14'),(31,1,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-19 09:44:33'),(32,1,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-19 09:45:41'),(33,1,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-19 09:46:00'),(34,1,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-19 09:46:19'),(35,1,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-19 09:47:07'),(36,1,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-19 09:47:09'),(37,1,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-19 09:47:25'),(38,1,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-19 09:49:46'),(39,1,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-19 09:49:47'),(40,1,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-19 09:50:36'),(41,1,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-19 09:52:29'),(42,1,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-19 09:52:31'),(43,1,'logout','Logout: Super Administrator','local',NULL,'2026-07-19 09:57:41'),(44,1,'login','Login: Super Administrator','unknown',NULL,'2026-07-19 09:59:14'),(45,1,'create_user','Menambah user: Muhammad Rama Alfiannur','local',NULL,'2026-07-19 10:00:09'),(46,1,'logout','Logout: Super Administrator','local',NULL,'2026-07-19 10:00:24'),(47,14,'login','Login: Muhammad Rama Alfiannur','unknown',NULL,'2026-07-19 10:00:33'),(48,14,'logout','Logout: Muhammad Rama Alfiannur','local',NULL,'2026-07-19 10:01:22'),(49,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-19 10:13:50'),(50,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-19 10:14:01'),(51,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-19 10:19:03'),(52,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-19 10:19:14'),(53,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-20 00:41:00'),(54,15,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-20 00:42:15'),(55,15,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-20 00:47:38'),(56,15,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-20 00:47:40'),(57,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-20 00:48:46'),(58,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-20 01:02:29'),(59,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-20 01:13:02'),(60,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-20 02:31:34'),(61,15,'bulk_upload','Upload bulk 2 buku dari Excel','local',NULL,'2026-07-20 02:33:37'),(62,15,'delete_book','Menghapus buku: Buku Ajar Matematika','local',NULL,'2026-07-20 02:33:53'),(63,15,'delete_book','Menghapus buku: Tesis Analisis Data','local',NULL,'2026-07-20 02:33:55'),(64,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-20 02:36:07'),(65,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-20 05:54:06'),(66,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-20 08:24:53'),(67,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-20 08:25:25'),(68,15,'add_bookmark','Tambah bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-20 08:25:44'),(69,15,'remove_bookmark','Hapus bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-20 08:25:54'),(70,15,'add_bookmark','Tambah bookmark: Buku Ajar Basis Data','local',NULL,'2026-07-20 08:26:09'),(71,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-20 08:27:40'),(72,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-20 08:30:45'),(73,15,'add_bookmark','Tambah bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-21 02:05:09'),(74,15,'remove_bookmark','Hapus bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-21 02:05:12'),(75,15,'add_bookmark','Tambah bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-21 02:05:13'),(76,15,'remove_bookmark','Hapus bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-21 02:06:19'),(77,15,'add_bookmark','Tambah bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-21 02:08:41'),(78,15,'remove_bookmark','Hapus bookmark: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-21 02:08:42'),(79,15,'add_bookmark','Tambah bookmark: Farmakologi Klinis untuk Praktisi Kesehatan','local',NULL,'2026-07-21 02:08:49'),(80,15,'remove_bookmark','Hapus bookmark: Farmakologi Klinis untuk Praktisi Kesehatan','local',NULL,'2026-07-21 02:08:50'),(81,15,'add_bookmark','Tambah bookmark: Buku Ajar Data Mining','local',NULL,'2026-07-21 02:43:20'),(82,15,'unblock_user','Membuka blokir user: Pustakawan 01','local',NULL,'2026-07-21 07:09:22'),(83,16,'login','Login: Pustakawan 01','unknown',NULL,'2026-07-21 07:09:45'),(84,16,'logout','Logout: Pustakawan 01','local',NULL,'2026-07-21 07:09:49'),(85,15,'unblock_user','Membuka blokir user: Pustakawan 01','local',NULL,'2026-07-21 07:11:46'),(86,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-22 01:19:58'),(87,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-22 01:34:14'),(88,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-22 01:51:12'),(89,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-22 01:53:00'),(90,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-22 02:02:05'),(91,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-22 02:06:07'),(92,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-22 02:47:38'),(93,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-22 03:25:19'),(94,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-22 03:35:16'),(95,15,'create_book','Menambah buku: The Grapes of Wrath','local',NULL,'2026-07-22 06:56:36'),(96,15,'delete_book','Menghapus buku: The Grapes of Wrath','local',NULL,'2026-07-22 06:56:39'),(97,15,'create_book','Menambah buku: To Kill a Mockingbird','local',NULL,'2026-07-22 07:01:01'),(98,15,'delete_book','Menghapus buku: To Kill a Mockingbird','local',NULL,'2026-07-22 07:01:10'),(99,15,'delete_book','Menghapus buku: Asuhan Kebidanan pada Ibu Hamil Patologi','local',NULL,'2026-07-22 07:31:53'),(100,15,'delete_book','Menghapus buku: Buku Ajar Pemrograman Web','local',NULL,'2026-07-22 07:32:33'),(101,15,'delete_book','Menghapus buku: Buku Ajar Algoritma','local',NULL,'2026-07-22 07:32:35'),(102,15,'delete_book','Menghapus buku: Buku Ajar Data Mining','local',NULL,'2026-07-22 07:32:37'),(103,15,'delete_book','Menghapus buku: Buku Ajar Jaringan Komputer','local',NULL,'2026-07-22 07:32:38'),(104,15,'delete_book','Menghapus buku: Buku Ajar Basis Data','local',NULL,'2026-07-22 07:32:40'),(105,15,'delete_book','Menghapus buku: Buku Ajar Statistika','local',NULL,'2026-07-22 07:32:41'),(106,15,'delete_book','Menghapus buku: Buku Ajar Kecerdasan Buatan','local',NULL,'2026-07-22 07:32:44'),(107,15,'delete_book','Menghapus buku: Buku Ajar Sistem Operasi','local',NULL,'2026-07-22 07:32:46'),(108,15,'delete_book','Menghapus buku: Buku Ajar Rekayasa Perangkat Lunak','local',NULL,'2026-07-22 07:32:47'),(109,15,'delete_book','Menghapus buku: Buku Ajar Grafika Komputer','local',NULL,'2026-07-22 07:32:49'),(110,15,'delete_book','Menghapus buku: Buku Ajar Komputasi Awan','local',NULL,'2026-07-22 07:32:50'),(111,15,'delete_book','Menghapus buku: Buku Ajar Keamanan Siber','local',NULL,'2026-07-22 07:33:29'),(112,15,'delete_book','Menghapus buku: Dasar-Dasar Keperawatan Medikal Bedah','local',NULL,'2026-07-22 07:33:31'),(113,15,'delete_book','Menghapus buku: Farmakologi Klinis untuk Praktisi Kesehatan','local',NULL,'2026-07-22 07:33:32'),(114,15,'delete_book','Menghapus buku: Pemrograman Web Modern dengan Laravel dan Vue.js','local',NULL,'2026-07-22 07:33:34'),(115,15,'delete_book','Menghapus buku: Jurnal Ilmu Kesehatan Vol. 12 No. 1','local',NULL,'2026-07-22 07:33:36'),(116,15,'create_book','Menambah buku: To Kill a Mockingbird','local',NULL,'2026-07-23 01:55:13'),(117,15,'add_bookmark','Tambah bookmark: To Kill a Mockingbird','local',NULL,'2026-07-23 01:56:10'),(118,15,'remove_bookmark','Hapus bookmark: To Kill a Mockingbird','local',NULL,'2026-07-23 01:56:13'),(119,15,'add_bookmark','Tambah bookmark: To Kill a Mockingbird','local',NULL,'2026-07-23 01:56:15'),(120,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-23 02:09:37'),(121,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-23 02:10:53'),(122,15,'remove_bookmark','Hapus bookmark: To Kill a Mockingbird','local',NULL,'2026-07-23 07:35:15'),(123,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-25 06:25:58'),(124,15,'create_book','Menambah buku: The Grapes of Wrath','local',NULL,'2026-07-25 06:26:33'),(125,15,'update_book','Mengedit buku: To Kill a Mockingbird','local',NULL,'2026-07-25 06:28:30'),(126,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-27 02:35:30'),(127,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-27 06:30:00'),(128,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-27 06:48:43'),(129,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-27 07:37:30'),(130,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-27 07:38:19'),(131,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-47-46.sql','local',NULL,'2026-07-28 03:50:44'),(132,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-52-30.sql','local',NULL,'2026-07-28 03:52:33'),(133,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-52-26.sql','local',NULL,'2026-07-28 03:52:35'),(134,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-50-51.sql','local',NULL,'2026-07-28 03:52:36'),(135,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-55-50.sql','local',NULL,'2026-07-28 03:55:59'),(136,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-55-28.sql','local',NULL,'2026-07-28 03:56:02'),(137,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T03-58-04.sql','local',NULL,'2026-07-28 03:59:17'),(138,15,'backup_export','Export SQL: sari-backup-2026-07-28T04-02-28.sql','local',NULL,'2026-07-28 04:02:29'),(139,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T04-02-28.sql','local',NULL,'2026-07-28 04:02:46'),(140,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T04-02-29.sql','local',NULL,'2026-07-28 04:02:48'),(141,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T04-02-26.sql','local',NULL,'2026-07-28 04:02:54'),(142,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T04-02-16.sql','local',NULL,'2026-07-28 04:02:59'),(143,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T04-03-00.sql','local',NULL,'2026-07-28 06:04:19'),(144,15,'backup_export','Export SQL: sari-backup-2026-07-28T06-19-53.sql','local',NULL,'2026-07-28 06:19:53'),(145,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T06-19-53.sql','local',NULL,'2026-07-28 06:19:59'),(146,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T06-19-21.sql','local',NULL,'2026-07-28 06:20:01'),(147,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T06-19-21_tmp.sql','local',NULL,'2026-07-28 06:20:02'),(148,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T07-31-17.sql','local',NULL,'2026-07-28 07:36:49'),(149,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-28 07:38:50'),(150,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T07-42-42.sql','local',NULL,'2026-07-28 07:43:00'),(151,15,'backup_delete','Hapus backup: sari-backup-2026-07-28T07-53-40.sql','local',NULL,'2026-07-29 01:09:05'),(152,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-29 01:10:36'),(153,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-29 01:11:01'),(154,15,'backup_export','Export SQL: sari-backup-2026-07-29T01-12-24.sql','local',NULL,'2026-07-29 01:12:25'),(155,15,'backup_delete','Hapus backup: sari-backup-2026-07-29T01-12-24.sql','local',NULL,'2026-07-29 01:12:30'),(156,15,'backup_delete','Hapus backup: sari-backup-2026-07-29T01-12-31.sql','local',NULL,'2026-07-29 01:12:36'),(157,15,'backup_delete','Hapus backup: sari-backup-2026-07-29T02-29-13.rar','local',NULL,'2026-07-29 02:30:21'),(158,15,'delete_book','Menghapus buku: The Grapes of Wrath','local',NULL,'2026-07-29 02:30:29'),(159,15,'delete_book','Menghapus buku: To Kill a Mockingbird','local',NULL,'2026-07-29 02:30:30'),(160,15,'create_book','Menambah buku: The Grapes of Wrath','local',NULL,'2026-07-29 02:30:55'),(161,15,'backup_export','Export SQL Dump (.sql): sari-backup-2026-07-29T02-31-01.sql','local',NULL,'2026-07-29 02:31:02'),(162,15,'backup_export','Export ZIP Archive (.zip): sari-backup-2026-07-29T02-31-05.zip','local',NULL,'2026-07-29 02:31:07'),(163,15,'backup_delete','Hapus backup: sari-backup-2026-07-29T02-31-05.zip','local',NULL,'2026-07-29 02:50:12'),(164,15,'backup_delete','Hapus backup: sari-backup-2026-07-29T02-31-01.sql','local',NULL,'2026-07-29 02:50:14'),(165,15,'backup_export','Export ZIP Archive (.zip): sari-backup-2026-07-29T02-54-30.zip','local',NULL,'2026-07-29 02:54:32'),(166,15,'backup_import','Import: sari-backup-2026-07-29T02-54-40.sql','local',NULL,'2026-07-29 02:57:18'),(167,15,'delete_book','Menghapus buku: The Grapes of Wrath','local',NULL,'2026-07-29 02:57:22'),(168,15,'create_book','Menambah buku: The Grapes of Wrath','local',NULL,'2026-07-29 02:57:42'),(169,15,'backup_export','Export ZIP Archive (.zip): sari-backup-2026-07-29T02-57-48.zip','local',NULL,'2026-07-29 02:57:50'),(170,15,'backup_delete','Hapus backup: sari-backup-2026-07-29T02-57-48.zip','local',NULL,'2026-07-29 02:57:54'),(171,15,'backup_import','Import: sari-backup-2026-07-29T02-57-57.sql','local',NULL,'2026-07-29 03:03:58'),(172,15,'delete_book','Menghapus buku: The Grapes of Wrath','local',NULL,'2026-07-29 03:04:02'),(173,15,'create_book','Menambah buku: To Kill a Mockingbird','local',NULL,'2026-07-29 03:06:09'),(174,15,'backup_export','Export SQL Dump (.sql): sari-backup-2026-07-29T03-06-16.sql','local',NULL,'2026-07-29 03:06:17'),(175,15,'backup_import','Import: sari-backup-2026-07-29T03-06-19.zip','local',NULL,'2026-07-29 03:07:49'),(176,15,'delete_book','Menghapus buku: To Kill a Mockingbird','local',NULL,'2026-07-29 03:07:53'),(177,15,'create_book','Menambah buku: To Kill a Mockingbird','local',NULL,'2026-07-29 03:12:16'),(178,15,'backup_import','Import: sari-backup-2026-07-29T03-12-33.zip','local',NULL,'2026-07-29 06:27:11'),(179,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-29 06:46:05'),(180,NULL,'login','Login: Muhammad Fahrul Bahri','unknown',NULL,'2026-07-29 07:05:01'),(181,NULL,'logout','Logout: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:05:23'),(182,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-29 07:05:54'),(183,15,'delete_user','Menghapus user: Husni','local',NULL,'2026-07-29 07:06:07'),(184,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:06:10'),(185,15,'delete_user','Menghapus user: Rama','local',NULL,'2026-07-29 07:06:19'),(186,15,'delete_user','Menghapus user: Masyarakat Umum','local',NULL,'2026-07-29 07:06:34'),(187,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-29 07:09:29'),(188,15,'login','Login: Fahrul Bahri','unknown',NULL,'2026-07-29 07:10:23'),(189,15,'delete_user','Menghapus user: Popup Test','local',NULL,'2026-07-29 07:10:29'),(190,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:10:39'),(191,15,'delete_user','Menghapus user: Final Test','local',NULL,'2026-07-29 07:14:36'),(192,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:14:38'),(193,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:15:28'),(194,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:18:18'),(195,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:21:57'),(196,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-29 07:25:07'),(198,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-30 01:05:16'),(200,15,'delete_user','Menghapus user: Muhammad Fahrul Bahri','local',NULL,'2026-07-30 01:07:49'),(202,30,'logout','Logout: Muhammad Fahrul Bahri','local',NULL,'2026-07-30 01:16:23'),(203,30,'login','Login: Muhammad Fahrul Bahri','unknown',NULL,'2026-07-30 01:33:14'),(204,30,'logout','Logout: Muhammad Fahrul Bahri','local',NULL,'2026-07-30 01:33:40'),(205,30,'login','Login: Muhammad Fahrul Bahri','unknown',NULL,'2026-07-30 01:55:37'),(206,30,'logout','Logout: Muhammad Fahrul Bahri','local',NULL,'2026-07-30 01:56:18'),(207,15,'logout','Logout: Fahrul Bahri','local',NULL,'2026-07-30 03:38:43'),(208,14,'login','Login: Muhammad Rama Alfiannur','unknown',NULL,'2026-07-30 06:12:45'),(209,14,'login','Login: Muhammad Rama Alfiannur','unknown',NULL,'2026-07-30 06:48:33'),(210,14,'update_book','Mengedit buku: To Kill a Mockingbird','local',NULL,'2026-07-30 06:49:27'),(211,14,'update_book','Mengedit buku: To Kill a Mockingbird','local',NULL,'2026-07-30 06:50:13'),(212,14,'update_book','Mengedit buku: To Kill a Mockingbird','local',NULL,'2026-07-30 06:52:23');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `book_program`
--

DROP TABLE IF EXISTS `book_program`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `book_program` (
  `book_id` int unsigned NOT NULL,
  `program_id` int unsigned NOT NULL,
  PRIMARY KEY (`book_id`,`program_id`),
  KEY `fk_bp_program` (`program_id`),
  CONSTRAINT `fk_bp_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bp_program` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_program`
--

LOCK TABLES `book_program` WRITE;
/*!40000 ALTER TABLE `book_program` DISABLE KEYS */;
INSERT INTO `book_program` VALUES (44,9),(44,11);
/*!40000 ALTER TABLE `book_program` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookmarks`
--

DROP TABLE IF EXISTS `bookmarks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookmarks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `book_id` int unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_bookmarks_user_book` (`user_id`,`book_id`),
  KEY `idx_bookmarks_user` (`user_id`),
  KEY `idx_bookmarks_book` (`book_id`),
  CONSTRAINT `fk_bookmarks_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_bookmarks_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookmarks`
--

LOCK TABLES `bookmarks` WRITE;
/*!40000 ALTER TABLE `bookmarks` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookmarks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `books` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int unsigned DEFAULT NULL,
  `uploaded_by` int unsigned NOT NULL,
  `title` varchar(300) NOT NULL,
  `slug` varchar(350) NOT NULL,
  `author` varchar(250) NOT NULL DEFAULT '',
  `publisher` varchar(200) DEFAULT NULL,
  `publication_year` year DEFAULT NULL,
  `isbn` varchar(30) DEFAULT NULL,
  `description` text,
  `access_type` enum('public','internal') NOT NULL DEFAULT 'public',
  `file_path` varchar(500) NOT NULL,
  `cover_image` varchar(500) DEFAULT NULL,
  `page_count` smallint unsigned DEFAULT '0',
  `file_size` int unsigned DEFAULT '0',
  `views` int unsigned DEFAULT '0',
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `idx_books_access` (`access_type`,`status`),
  KEY `idx_books_category` (`category_id`),
  KEY `idx_books_uploader` (`uploaded_by`),
  FULLTEXT KEY `ft_books_search` (`title`,`author`,`description`),
  CONSTRAINT `fk_books_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_books_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `books`
--

LOCK TABLES `books` WRITE;
/*!40000 ALTER TABLE `books` DISABLE KEYS */;
INSERT INTO `books` VALUES (44,NULL,15,'To Kill a Mockingbird','to-kill-a-mockingbird','Harper Lee','Harper Perennial Modern Classics',2006,'9780061120084','Salah satu cerita yang paling dicintai sepanjang masa, To Kill a Mockingbird telah diterjemahkan ke lebih dari empat puluh bahasa, terjual lebih dari tiga puluh juta kopi di seluruh dunia, menjadi dasar film yang sangat populer, dan terpilih sebagai salah satu novel terbaik abad kedua puluh oleh pustakawan di seluruh negeri. Sebuah kisah yang mencekam, menyayat hati, dan sangat luar biasa tentang masa dewasa di wilayah Selatan yang diracuni oleh prasangka jahat, film ini memandang dunia yang sangat indah dan ketidakadilan yang kejam dari sudut pandang seorang gadis muda, ketika ayahnya - seorang pengacara lokal yang berjuang keras - mempertaruhkan segalanya untuk membela seorang pria kulit hitam yang dituduh melakukan kejahatan mengerikan secara tidak adil.\r\n\r\n(penutup depan)','public','to-kill-a-mockingbird-1785294735992.pdf','ol-9780061120084.jpg',2,0,2,'active','2026-07-29 03:12:16','2026-07-30 06:52:31');
/*!40000 ALTER TABLE `books` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `slug` varchar(180) NOT NULL,
  `description` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (3,'Disertasi','disertasi','Karya ilmiah mahasiswa S3','2026-07-17 06:42:48'),(4,'Buku Ajar','buku-ajar','Materi perkuliahan resmi','2026-07-17 06:42:48'),(5,'Referensi Umum','referensi-umum','Buku referensi untuk publik','2026-07-17 06:42:48'),(6,'Jurnal','jurnal','Jurnal ilmiah internal kampus','2026-07-17 06:42:48');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `faculties`
--

DROP TABLE IF EXISTS `faculties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faculties` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `slug` varchar(220) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculties`
--

LOCK TABLES `faculties` WRITE;
/*!40000 ALTER TABLE `faculties` DISABLE KEYS */;
INSERT INTO `faculties` VALUES (1,'Kesehatan','kesehatan','Fakultas Ilmu Kesehatan','2026-07-17 08:23:01'),(2,'Humaniora','humaniora','Fakultas Humaniora','2026-07-17 08:23:01'),(3,'Sains dan Teknologi','sains-dan-teknologi','Fakultas Sains dan Teknologi','2026-07-17 08:23:01'),(4,'Kedokteran Hewan','kedokteran-hewan','Fakultas Kedokteran Hewan','2026-07-17 08:23:01');
/*!40000 ALTER TABLE `faculties` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_password_resets_user` (`user_id`),
  KEY `idx_password_resets_token` (`token`),
  CONSTRAINT `fk_password_resets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
INSERT INTO `password_resets` VALUES (2,30,'1011cd83090d53a14377a105b9e6ec512ad928b603d052e924f6259ed94d29ce','2026-07-30 02:25:03',1,'2026-07-30 01:25:03'),(3,30,'374d03a92ea336a73dd426e18b7d5ea70f8ee7c0a4adaeb744ffa6109ee1964d','2026-07-30 02:25:05',1,'2026-07-30 01:25:05'),(4,30,'c75dc13981ebe1d229abc316bd08a3ae20d05f1db517948eac3c97af09d1519d','2026-07-30 02:25:06',1,'2026-07-30 01:25:06'),(5,30,'9ced96d6e29e36a73093f1ac37c9307bbd58aa103d59bc2eb4fd21f43a3fdc99','2026-07-30 02:25:06',1,'2026-07-30 01:25:06'),(6,30,'87c807478b5b1dd541673a6c8de2f0f9185b5dba99ad34bbcc276b3b3145c8a0','2026-07-30 02:25:06',1,'2026-07-30 01:25:06'),(7,30,'7fb082580a1b5208b2510e76760545f8ded109b9e1bc5a906fd485b99b7db2ae','2026-07-30 02:25:06',1,'2026-07-30 01:25:06'),(8,30,'96fe8cf12e364178d0b0c4a4f7d28150967e6963d5d412c706acf6b5b9fe02f9','2026-07-30 02:26:00',1,'2026-07-30 01:26:00'),(10,15,'a4f9713391934ceaf6c3199a23a03b591195343f38c9970ec09082bbfaf1284a','2026-07-30 02:30:37',1,'2026-07-30 01:30:37'),(11,15,'cc401b8cd76a16c1e3fbf13ecb8f6f84d796a4a670c919452f68dc6f6fc91dd2','2026-07-30 10:31:50',1,'2026-07-30 01:31:50'),(12,30,'e2274cd2d3727ed565bf79c0fcfc97043121d21fa1d483627bcf01f80cff4fde','2026-07-30 10:32:36',1,'2026-07-30 01:32:36'),(13,30,'39e4b68eaf0934d5ed2b157abbac6ab9cece593a7bf97ecf9e8da519793b1d6f','2026-07-30 10:54:35',1,'2026-07-30 01:54:35'),(14,30,'c609b7bcd9c34d78b3e4946b264811bfd2ea0394983710136aeeb84a6cc22ff5','2026-07-30 10:57:50',1,'2026-07-30 01:57:50'),(15,30,'c85dd7a84bd507da220c85540da864fe870dabd1c0b14d254bf73c3cdf4ea86d','2026-07-30 12:40:58',1,'2026-07-30 03:40:58'),(16,30,'94535bdf53fffce45b266e5ee8a2cbb1a8735febf2ebe2aa79b6166c8b845790','2026-07-30 12:45:45',1,'2026-07-30 03:45:45'),(17,30,'463c23c3ae0aa1ca3b6cf4bd0fc1cc136d76b3147b08731318362b3257055ff8','2026-07-30 12:46:20',0,'2026-07-30 03:46:20');
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `programs` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `faculty_id` int unsigned NOT NULL,
  `name` varchar(200) NOT NULL,
  `slug` varchar(220) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `faculty_id` (`faculty_id`),
  CONSTRAINT `programs_ibfk_1` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
INSERT INTO `programs` VALUES (1,1,'Kebidanan','kebidanan','2026-07-17 08:23:01'),(2,1,'Keperawatan','keperawatan','2026-07-17 08:23:01'),(3,1,'Farmasi','farmasi','2026-07-17 08:23:01'),(4,1,'Terapan Promosi Kesehatan','terapan-promosi-kesehatan','2026-07-17 08:23:01'),(5,2,'Sarjana Akuntansi','sarjana-akuntansi','2026-07-17 08:23:01'),(6,2,'Sarjana Hukum','sarjana-hukum','2026-07-17 08:23:01'),(7,2,'Sarjana Manajemen','sarjana-manajemen','2026-07-17 08:23:01'),(8,2,'Pendidikan Bahasa Inggris','pendidikan-bahasa-inggris','2026-07-17 08:23:01'),(9,3,'Sistem Informasi','sistem-informasi','2026-07-17 08:23:01'),(10,3,'Teknik Industri','teknik-industri','2026-07-17 08:23:01'),(11,3,'Teknologi Informasi','teknologi-informasi','2026-07-17 08:23:01'),(12,4,'Kedokteran Hewan','kedokteran-hewan','2026-07-17 08:23:01');
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reading_history`
--

DROP TABLE IF EXISTS `reading_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reading_history` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int unsigned NOT NULL,
  `book_id` int unsigned NOT NULL,
  `last_page` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reading_history_user_book` (`user_id`,`book_id`),
  KEY `fk_reading_history_book` (`book_id`),
  KEY `idx_reading_history_user` (`user_id`),
  CONSTRAINT `fk_reading_history_book` FOREIGN KEY (`book_id`) REFERENCES `books` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_reading_history_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reading_history`
--

LOCK TABLES `reading_history` WRITE;
/*!40000 ALTER TABLE `reading_history` DISABLE KEYS */;
INSERT INTO `reading_history` VALUES (231,14,44,0,'2026-07-30 06:49:35','2026-07-30 06:52:31');
/*!40000 ALTER TABLE `reading_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` tinyint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'super_admin','Kontrol penuh sistem & manajemen admin','2026-07-17 06:42:48'),(2,'admin','Pustakawan — CRUD buku, kategori, user','2026-07-17 06:42:48'),(3,'mahasiswa','Mahasiswa — akses semua buku publik & internal','2026-07-17 06:42:48'),(4,'tamu','Masyarakat umum — hanya buku publik','2026-07-17 06:42:48');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `role_id` tinyint unsigned NOT NULL,
  `username` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nim_nip` varchar(50) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `verified_at` datetime DEFAULT NULL,
  `failed_login_attempts` int unsigned NOT NULL DEFAULT '0',
  `locked_until` datetime DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_users_role` (`role_id`),
  KEY `idx_users_status` (`status`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'super','Super Administrator','superadmin@sarimulia.banjarmasin','$2a$10$RRE7wuN1b3Pgx..R/w1gZOL9Aj4CKeN0dQKwt895cxYkK7pOBFK1m','196001012010011001','active','2026-07-29 14:48:22',0,NULL,NULL,'2026-07-17 06:42:48','2026-07-29 06:48:22'),(14,1,'Rama Alfiannur','Muhammad Rama Alfiannur','Rama@gmail.com','$2a$10$X0gMThzbkZPwtvzRwXN.z.Cp1v6BgKdBivR0etgP2BBOXwodYHvbC',NULL,'active','2026-07-29 14:48:22',0,NULL,NULL,'2026-07-19 10:00:09','2026-07-29 06:48:22'),(15,1,'fahrul_admin','Fahrul Bahri','Fahrul@gmail.com','$2a$10$tAW6LBF1ej8/QFOL/7KHz.aJo/vUR1qFgzBnb/dnq8aqq3RJjAwCC','NIP001','active','2026-07-29 14:48:22',0,NULL,NULL,'2026-07-19 10:10:10','2026-07-30 01:31:55'),(16,2,'pustakawan01','Pustakawan 01','Pustakawan01@gmail.com','$2a$10$d6PWcBFatVMrx9/dwuzxseeNAX8Dj.vD5srVdygaP9V/tTeEB8O1O','NIP002','active','2026-07-29 14:48:22',0,NULL,NULL,'2026-07-19 10:10:10','2026-07-29 06:48:22'),(17,3,'mahasiswa01','Mahasiswa 01','Mahasiswa01@gmail.com','$2a$10$MvNQFVbU376Tut7EVe//quKK4ua6yUYJgXjHEit8wyOn9zQbHobpq','NIM001','active',NULL,0,NULL,NULL,'2026-07-19 10:10:10','2026-07-19 10:10:10'),(30,4,'fahrulbahri0520','Muhammad Fahrul Bahri','fahrulbahri0520@gmail.com','$2a$10$EYKFDJd3rW6yYvNu.h0aYeFSw1YhX/jfH1TqZp0SpTIhpNECqKxTm',NULL,'active','2026-07-30 09:16:10',0,NULL,NULL,'2026-07-30 01:15:43','2026-07-30 01:58:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification_tokens`
--

DROP TABLE IF EXISTS `verification_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification_tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(200) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_token` (`token`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification_tokens`
--

LOCK TABLES `verification_tokens` WRITE;
/*!40000 ALTER TABLE `verification_tokens` DISABLE KEYS */;
INSERT INTO `verification_tokens` VALUES (1,'husnimajedi@gmail.com','85d277145bbcb4dbbbf26737f5c174d4247ae578ced342275938d37e253db498','2026-07-30 11:24:00','2026-07-29 03:23:59'),(4,'resendtest@example.com','a6ae0937944947490f30e5dc49dc121c8636e5bf963bc7d1208590f0e4b637af','2026-07-30 11:45:42','2026-07-29 03:45:41'),(5,'testfinal@contoh.com','1f256563d44b3b2a736ba20f3ee8c4c24b1c4972e560e9493c4c529cecbc753a','2026-07-30 11:46:53','2026-07-29 03:46:53'),(6,'tampangawang756@gmail.com','f2d0a149ceadf2041263c2f8fa2f2d0e54ea5582e4e6d75bf5c0b5ff62b1a9f0','2026-07-30 11:47:37','2026-07-29 03:47:37'),(7,'testdomain@contoh.com','b40994f0e289b18f77508b46f5590e86bbfce42b42c8a2eb2bcc9de8913a1062','2026-07-30 11:58:34','2026-07-29 03:58:34'),(8,'ramain027@gmail.com','d231989a6c515e726ac01c584af3e8394418d1dfede24f64b0ca4f96e6cb5a7f','2026-07-30 14:50:06','2026-07-29 06:50:05'),(13,'fahrulbahri830@gmail.com','d7b4d2ba1a1d15ac9e2f98d299fd43747b608b4641b994408bd3edb2028c5c61','2026-07-30 15:01:10','2026-07-29 07:01:09'),(14,'husnimajedi@gmail.com','78516f6f3dafb8566bee11963b2301a957caa7092165c9b1174f48a95455f8b7','2026-07-30 15:04:06','2026-07-29 07:04:05'),(15,'poptest@gmail.com','51cf9bf22f68b5c3384f66acfbd27df6c53b2dc2e2ecaa0470609a9f14273df2','2026-07-30 15:08:53','2026-07-29 07:08:53'),(17,'finaltest@gmail.com','d7a45d0a23191f781ba5eb78141427865cc5322575a9e820565066e597276118','2026-07-30 15:14:13','2026-07-29 07:14:12');
/*!40000 ALTER TABLE `verification_tokens` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-30 14:52:46
